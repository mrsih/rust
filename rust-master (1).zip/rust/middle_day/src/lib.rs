pub use chrono::*;
pub type wd = Weekday;

pub fn middle_day(year: i32) -> Option<wd> {
    let aasta = NaiveDate::from_yo(year, 1);
    let aasta2 = NaiveDate::from_yo(year + 1, 1);
    let aasta3 = aasta2 - aasta;
    if aasta3.num_days() % 2 == 0 {
        return None;
    }
    Some(NaiveDate::from_yo(year, 183).weekday())
}