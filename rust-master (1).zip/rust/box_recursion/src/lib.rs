use std::mem;
#[derive(Debug)]
pub struct WorkEnvironment {
    pub grade: Link,
}
pub type Link = Option<Box<Worker>>;
#[derive(Debug)]
pub struct Worker {
    pub worker_type: String,
    pub worker_name: String,
    pub next_worker: Link,
}
impl WorkEnvironment {
    pub fn new() -> WorkEnvironment {
        WorkEnvironment {
            grade: None,
        }
    }
    pub fn add_worker(&mut self, t: String, name: String) {
        let new_node = Box::new(Worker {
            worker_type: t,
            worker_name: name,
            next_worker: self.grade.take(),
        });
        self.grade = Some(new_node);
    }
    pub fn remove_worker(&mut self) -> Option<String> {
        match mem::replace(&mut self.grade, None) {
            None => None,
            Some(node) => {
                self.grade = node.next_worker;
                Some(node.worker_name)
            }
        }
    }
    pub fn search_worker(&self) -> Option<(String, String)> {
        match &self.grade {
            None => None,
            Some(node) => Some((node.worker_name.clone(), node.worker_type.clone())),
        }
    }
}