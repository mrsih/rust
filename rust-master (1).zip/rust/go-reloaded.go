// ne moi 1
package main

import (
	"fmt"
	"io/ioutil"
	"os"
	"strconv"
	"strings"
)

func main() {
	if len(os.Args[1:]) < 2 {
		fmt.Println("File name missing")
	} else if len(os.Args[1:]) > 2 {
		fmt.Println("Too many arguments")
	} else {
		inputStr, err := ioutil.ReadFile(os.Args[1])
		if err != nil {
			fmt.Println("Error reading a file")
		}
		// end of reading a file

		fmt.Println("\tinput")
		in := string(inputStr)
		fmt.Println(in)
		in = prepare(in)

		input := strings.Fields(in)
		input = checkNum(input, "(hex)")
		input = checkNum(input, "(bin)")
		input = checkWords(input, "(up,")
		input = checkWords(input, "(low,")
		input = checkWords(input, "(cap,")
		input = checkAorAN(input)
		input = ponctuation(input)
		result := strings.Join(input, " ")
		result = finalize(result)

		fmt.Println("\n\toutput")
		fmt.Println(result)

		// start of writing into a file
		outFile := os.Args[2]
		output, err := os.Create(outFile)
		if err != nil {
			fmt.Println("Error creating a file")
		}
		defer output.Close()
		_, err2 := output.WriteString(result)
		if err2 != nil {
			fmt.Println("Error writing in a file")
		}
	}
}

func finalize(input string) string {
	input = strings.ReplaceAll(input, "   ", " ")
	input = strings.ReplaceAll(input, "  ", " ")
	input = strings.ReplaceAll(input, " ?", "?")
	input = strings.ReplaceAll(input, " !", "!")
	input = strings.ReplaceAll(input, " .", ".")
	input = strings.ReplaceAll(input, " ,", ",")
	input = strings.ReplaceAll(input, " ' ", "'")
	input = strings.ReplaceAll(input, " '", "'")
	input = strings.ReplaceAll(input, "' ", "'")
	input = strings.ReplaceAll(input, " ‘ ", "‘")
	input = strings.ReplaceAll(input, "‘ ", "‘")
	input = strings.ReplaceAll(input, " ‘", "‘")
	input = strings.ReplaceAll(input, " ’ ", "’")
	input = strings.ReplaceAll(input, "’ ", "’")
	input = strings.ReplaceAll(input, " ’", "’")
	input = strings.ReplaceAll(input, ":", ": ")
	input = strings.ReplaceAll(input, " :", ":")
	input = strings.ReplaceAll(input, "  ", " ")
	return input
}

func prepare(input string) string {
	input = strings.ReplaceAll(input, ")", ") ")
	input = strings.ReplaceAll(input, ":", ": ")
	input = strings.ReplaceAll(input, ";", "; ")
	input = strings.ReplaceAll(input, ".", ". ")
	input = strings.ReplaceAll(input, ",", ", ")
	input = strings.ReplaceAll(input, "?", "? ")
	input = strings.ReplaceAll(input, "!", "! ")
	input = strings.ReplaceAll(input, "(up)", "(up, 1)")
	input = strings.ReplaceAll(input, "(low)", "(low, 1)")
	input = strings.ReplaceAll(input, "(cap)", "(cap, 1)")
	return input
}

func checkNum(input []string, caseString string) []string {
	var result []string
	var base int
	if caseString == "(hex)" {
		base = 16
	}
	if caseString == "(bin)" {
		base = 2
	}
	for index, str := range input {
		if str == caseString {
			num, err := strconv.ParseInt(input[index-1], base, 64)
			if err != nil {
				fmt.Println("Error converting a number")
				num = 0
			}
			input[index-1] = strconv.Itoa(int(num))
		}
	}
	for _, word := range input {
		if word != caseString {
			result = append(result, word)
		}
	}
	return result
}

func checkWords(input []string, caseString string) []string {
	var result []string
	for index, str := range input {
		if str == caseString {
			num, err := strconv.Atoi(strings.Trim(input[index+1], ")"))
			if err != nil {
				fmt.Println("Error converting a number")
				num = 0
			}
			for x := 1; x <= num; x++ {
				if caseString == "(up," {
					input[index-x] = strings.ToUpper(input[index-x])
				}
				if caseString == "(low," {
					input[index-x] = strings.ToLower(input[index-x])
				}
				if caseString == "(cap," {
					input[index-x] = Capitalize(input[index-x])
				}
			}
			input[index+1] = ""
		}
	}
	for _, word := range input {
		if word != caseString {
			result = append(result, word)
		}
	}
	return result
}

func Capitalize(str string) string {
	s := []rune(str)
	result := ""
	if len(s) == 1 {
		result = strings.ToUpper(str)
	}
	if len(s) > 1 {
		result = strings.ToUpper(string(s[0]))
		result += strings.ToLower(string(s[1:]))
	}
	return result
}

func ponctuation(input []string) []string {
	for index, word := range input {
		if strings.HasPrefix(word, ".") {
			input[index] = strings.TrimPrefix(word, ".")
			input[index-1] += "."
		}
		if strings.HasPrefix(word, ",") {
			input[index] = strings.TrimPrefix(word, ",")
			input[index-1] += ","
		}
		if strings.HasPrefix(word, ":") {
			input[index] = strings.TrimPrefix(word, ":")
			input[index-1] += ":"
		}
		if strings.HasPrefix(word, ";") {
			input[index] = strings.TrimPrefix(word, ";")
			input[index-1] += ";"
		}
		if strings.HasPrefix(word, "!") {
			input[index] = strings.TrimPrefix(word, "!")
			input[index-1] += "!"
		}
		if strings.HasPrefix(word, "?") {
			input[index] = strings.TrimPrefix(word, "?")
			input[index-1] += "?"
		}
		if strings.HasPrefix(word, "...") {
			input[index] = strings.TrimPrefix(word, "...")
			input[index-1] += "..."
		}
		if strings.HasPrefix(word, "!?") {
			input[index] = strings.TrimPrefix(word, "!?")
			input[index-1] += "!?"
		}
		if strings.HasPrefix(word, "!!") {
			input[index] = strings.TrimPrefix(word, "!!")
			input[index-1] += "!!"
		}
		if strings.HasPrefix(word, "??") {
			input[index] = strings.TrimPrefix(word, "??")
			input[index-1] += "??"
		}
	}
	result := strings.Join(input, " ")
	input = strings.Fields(string(result))
	return input
}

func checkAorAN(input []string) []string {
	for index, word := range input {
		if word == "a" && isVowel(input[index+1]) {
			input[index] = "an"
		}
		if word == "A" && isVowel(input[index+1]) {
			input[index] = "An"
		}
		if word == "an" && !isVowel(input[index+1]) {
			input[index] = "a"
		}
		if word == "An" && !isVowel(input[index+1]) {
			input[index] = "A"
		}
	}
	return input
}

func isVowel(str string) bool {
	if str[0] == 'a' || str[0] == 'e' || str[0] == 'i' || str[0] == 'o' || str[0] == 'u' || str[0] == 'h' ||
		str[0] == 'A' || str[0] == 'E' || str[0] == 'I' || str[0] == 'O' || str[0] == 'U' || str[0] == 'H' {
		return true
	}
	return false
}
