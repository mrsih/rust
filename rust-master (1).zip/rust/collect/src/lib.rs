pub fn bubble_sort(vec: &mut Vec<i32>) {
    vec.sort();
}