echo
echo "input check standard"
go run . "input check standard"

echo
echo "First\nTest1 standard"
go run . "First\nTest1" standard

echo
echo "this is standard! standard"
go run . "this is standard!" standard

echo
echo "this is shadow! shadow"
go run . "this is shadow!" shadow

echo
echo "123 -> #$%&@ shadow "
go run . "123 -> #$%&@" shadow

echo
echo "this is thinkertoy! thinkertoy"
go run . "this is thinkertoy" thinkertoy

echo
echo "456 -> \"#$%@ thinkertoy"
go run . "456 -> \"#$%@" thinkertoy