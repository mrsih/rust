use core::fmt::Debug;
use std::clone::Clone;

#[derive(Clone, Debug)]
pub struct List<T: Clone> {
    pub head: Option<Node<T>>,
}

#[derive(Clone, Debug)]
pub struct Node<T: Clone> {
    pub value: T,
    pub next: Option<Box<Node<T>>>,
}

impl<T: Debug + Clone> List<T> {
    pub fn new() -> List<T> {
        List { head: None }
    }

    pub fn push(&mut self, value: T) {
        let current_list = self.clone();
        if self.head.is_none() {
            let last_node = Node { value, next: None };
            self.head = Some(last_node)
        } else {
            let next_node = current_list.head.unwrap();
            let last_node = Node {
                value,
                next: Some(Box::new(next_node)),
            };
            self.head = Some(last_node)
        }
    }

    pub fn pop(&mut self) {
        let current_list = self.clone();
        if current_list.head.is_none() { //do nothing
        } else {
            let current_list = current_list.head.unwrap().next;
            if current_list.is_none() {
                self.head = None;
            } else {
                let node = current_list.unwrap();
                self.head = Some(*node);
            }
        }
    }

    pub fn len(&self) -> usize {
        let mut count = 1;
        let node = self.head.clone();
        if node.is_none() {
            return 0;
        } else {
            let mut value = node.unwrap().next;
            if value.is_none() {
                return 1;
            } else {
                loop {
                    count += 1;
                    value = value.clone().unwrap().next;
                    if value.is_none() {
                        break;
                    }
                }
            }
        }
        count
    }
}