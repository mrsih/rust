pub fn first_subword(s: String) -> String {
    let mut word = String::new();
    let mut first = true;
    for letter in s.chars() {
        if letter == '_' || (letter.is_uppercase() && !first) { break }
        word.push(letter);
        first = false;
    }
    return word
}