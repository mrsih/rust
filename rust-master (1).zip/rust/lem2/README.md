To test the program run in your terminal

./tesh.sh
