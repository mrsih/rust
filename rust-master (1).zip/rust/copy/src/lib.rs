pub fn nbr_function(c: i32) -> (i32, f64, f64) {
    //     nbr_function returns a tuple:
            // with the original value.
            // the exponential function of the value.
            // and the natural logarithm of the absolute value.

    let c2 = c as f64;
    let exp = c2.exp();
    let log = c2.abs().ln();
    (c, exp, log)
}

pub fn str_function(a: String) -> (String, String) {
    //     str_function returns a tuple:
            // with the original value.
            // and the exponential function of each value as a string (see the example).

            let mut emptystring = String::new();
            let v: Vec<&str> = a.split(' ').collect();
            for number in v.iter() {
                if emptystring != "" {
                    emptystring += " "
                }
                let f = number.parse::<f64>().unwrap();
                let exp = f.exp();
                let string = exp.to_string();
                println!("{}", string);
               emptystring += &string;

            }
            (a, emptystring)
}

pub fn vec_function(b: Vec<i32>) -> (Vec<i32>, Vec<f64>) {
                let mut c:Vec<f64> = Vec::new();
                for element in &b{
                    c.push((*element as f64).ln());
                }
                return (b, c);

            let v: Vec<f64> = Vec::new();
            return (b,v)
}