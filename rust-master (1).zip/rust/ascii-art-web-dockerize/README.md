<h1>Description:</h1> 
<pre>Ascii art web project</pre>

<h1>Authors:</h1>
<pre>Mikk Sihvart, Viktor Afanasjev</pre>

<h1>Requirements:</h1>
    * WSL2 installed and running on your system
    (https://wslstorestorage.blob.core.windows.net/wslblob/wsl_update_x64.msi)

    * Docker installed and running on your system
    (https://www.docker.com/get-started)


<h1>Guide for WSL2</h1>
    -Search for and open Windows Powershell (run as administrator)
    -Check if your Ubuntu is running WSL2: "wsl -l -v"
    -If not then set WSL2 as your default: "wsl --set-default-version 2"
    -Set WSL2 on your Ubuntu: "wsl --set-version Ubuntu 2"
    -Check again if Ubuntu is running WSL2 now: "wsl -l -v"
    -Exit from Windows Powershell and restart your pc

<h1>To start just type "sh test.sh"</h1>
![img](https://pasteboard.co/aHt6HhDLoqCF.jpg)

<h1>Check "http://localhost:8080/"</h1>
![img](https://pasteboard.co/0f8MbDe9XbiH.jpg)




