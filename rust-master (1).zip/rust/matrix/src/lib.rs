use std::ops::{Add, Div, Mul, Sub};

#[derive(Debug, PartialEq, Clone)]
pub struct Matrix<T>(pub Vec<Vec<T>>);

pub trait Scalar: Copy + Sized + Add + Sub + Mul + Div {
    type Item;
    fn zero() -> Self::Item;
    fn one() -> Self::Item;
}
impl Scalar for u32 {
    type Item = Self;
    fn zero() -> Self::Item { 0 }
    fn one() -> Self::Item { 1 }
}
impl Scalar for u64 {
    type Item = Self;
    fn zero() -> Self::Item { 0 }
    fn one() -> Self::Item { 1 }
}
impl Scalar for i32 {
    type Item = Self;
    fn zero() -> Self::Item { 0 }
    fn one() -> Self::Item { 1 }
}
impl Scalar for i64 {
    type Item = Self;
    fn zero() -> Self::Item { 0 }
    fn one() -> Self::Item { 1 }
}
impl Scalar for f32 {
    type Item = Self;
    fn zero() -> Self::Item { 0.0 }
    fn one() -> Self::Item { 1.0 }
}
impl Scalar for f64 {
    type Item = Self;
    fn zero() -> Self::Item { 0.0 }
    fn one() -> Self::Item { 1.0 }
}

impl <T: Scalar<Item = T>> Matrix<T> {
    pub fn new(input: Vec<Vec<T>>) -> Matrix<T> {
        Matrix(input)
    }

    pub fn zero(row: usize, col: usize) -> Matrix<T> {
        let mut answer: Vec<Vec<T>> = vec![];

        let mut i = 0;
        while i < row {
            let mut temp_vec: Vec<T> = vec![];

            for _ in 0..col {
                temp_vec.push(T::zero())
            }
            answer.push(temp_vec);
            i += 1;
        }

        Matrix::new(answer)
    }

    pub fn identity(n: usize) -> Matrix<T> {
        let mut answer: Vec<Vec<T>> = vec![];

        let mut i = 0;
        while i < n {
            let mut temp_vec: Vec<T> = vec![];

            for k in 0..n {
                if k == i {
                    temp_vec.push(T::one());
                } else {
                    temp_vec.push(T::zero())
                }
            }
            answer.push(temp_vec);
            i += 1;
        }

        Matrix::new(answer)
    }
}