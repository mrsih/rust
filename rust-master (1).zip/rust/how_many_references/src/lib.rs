use std::rc;
pub use std::rc::Rc;

#[derive(Clone,Debug)]
pub struct Node {
    pub value: Vec<Rc<String>>,
}

impl Node {
    pub fn new(value: Vec<Rc<String>>) -> Node {
        Node { value: value }
    }
    pub fn add_ele(&mut self, v: Rc<String>) {
        self.value.push(v);
    }
    pub fn rm_all_ref(&mut self, v: Rc<String>) {
        self.value.retain(|s| {
            return Rc::as_ptr(s) != Rc::as_ptr(&v);
        });
    }
}

pub fn how_many_references(value: &Rc<String>) -> usize {
    Rc::strong_count(&value)
}