pub use chrono::{Utc, NaiveDate};
#[derive(Debug, Eq, PartialEq)]
pub struct FErr {
    pub form_values: (String,String),
    pub date: String,
    pub err: String
}
impl FErr {
    pub fn new(name: String, error: String, err: String) -> FErr {
        FErr{
            form_values: (name,error),
            date:  Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
            err: err,
        }
    }
}
#[derive(Debug, Eq, PartialEq)]
pub enum Color {
    Red,
    Green,
    Blue,
}
#[derive(Debug, Eq, PartialEq)]
pub struct Form {
    pub first_name: String,
    pub last_name: String,
    pub birth: NaiveDate,
    pub fav_colour: Color, 
    pub birth_location: String,
    pub password: String,
}
impl Form {
    pub fn new(first_name: String,last_name: String, birth: NaiveDate,
        fav_colour: Color,birth_location: String,password: String,) -> Form {
        
        Form{
            first_name: first_name,
            last_name: last_name,
            birth: birth,
            fav_colour: fav_colour,
            birth_location: birth_location,
            password: password,
        }
    }
    pub fn validate(&self) -> Result<Vec<&str>, FErr> {
        if self.first_name.is_empty(){
            return Err(FErr{
                        form_values: ("first_name".to_string(), "".to_string()),
                        date:  Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
                        err: "No user name".to_string(),
                    });
        
        }
        if self.password.len() < 8 {
            return Err(FErr{
                form_values: ("password".to_string(), self.password.to_owned()),
                date:  Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
                err: "At least 8 characters".to_string(),
            });
        }
        
        if !self.password.chars().any(|c| c.is_alphabetic())
            && !self.password.chars().any(|c| c.is_digit(10))
            && !self.password.chars().any(|c| !c.is_alphanumeric()){
                 return Err(FErr{
                form_values: ("password".to_string(), self.password.to_owned()),
                date:  Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
                err: "At least 8 characters".to_string(),
            });
        }
        if self.password.chars().any(|c| c.is_alphabetic())
        && self.password.chars().any(|c| c.is_digit(10))
        && self.password.chars().any(|c| !c.is_alphanumeric())
        {
        return Ok(Vec::from(["Valid first name","Valid password"]));
        } 
        Err(FErr{
            form_values: ("password".to_string(), self.password.to_owned()),
            date:  Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
            err: "Combination of different ASCII character types (numbers, letters and none alphanumeric characters)".to_string(),
        })
}
}