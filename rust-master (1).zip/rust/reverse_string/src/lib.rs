pub fn rev_str(input: &str) -> String {
    input.chars().rev().collect::<String>()
}