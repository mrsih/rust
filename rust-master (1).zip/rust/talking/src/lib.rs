pub fn talking(text: &str) -> &str {
    let last: String = text.chars().rev().take(1).collect();
    let second: String = text.chars().take(2).collect();
    let first: String = text.chars().take(1).collect();
    for c in text.chars() {
        if c.is_numeric() && last == "?" || second != second.to_uppercase() && first == first.to_uppercase() && last == "?"{
            return "Sure."
        }
    }
    if text.trim().is_empty() {return "Just say something!"}
    else if last == "?" && text == text.to_uppercase() && second == second.to_uppercase() {return "Quiet, I am thinking!"}
    else if last != "?" && text == text.to_uppercase() {return "There is no need to yell, calm down!"}
    return "Interesting"
}