pub fn factorial(mut num: u64) -> u64 {
    let mut sum: u64 = 1;
    while num > 1 {
        sum *= num;
        num -= 1;
    }
    return sum
}