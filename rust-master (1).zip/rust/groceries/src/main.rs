use std::io;

fn main() {
    let mut count: u64 = 0;
    let answer = String::from("The letter e\n");
    loop {
        let mut input = String::new();
        count = count + 1;
        io::stdin().read_line(&mut input).expect("NOOOOOOO");
        println!("I am the beginning of the end, and the end of time and space. I am essential to creation, and I surround every place. What am I?");
        if input == answer {
            println!("Number of trials: {}", count);
            break
        }
    }
}