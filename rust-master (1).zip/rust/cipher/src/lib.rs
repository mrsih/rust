#[derive(Debug, Clone, Eq, PartialEq)]
pub struct CipherError {
    pub validation: bool,
    pub expected: String,
}
impl CipherError {
    pub fn new(validation: bool, expected: String) -> CipherError {
        CipherError {
            validation: validation,
            expected: expected,
        }
    }
}
pub fn cipher(original: &str, ciphered: &str) -> Option<Result<bool, CipherError>> {
    if original == "" || ciphered == "" {
        return None;
    }
    let result = String::from_utf8(
        original.to_string().bytes().map(|t| {
            match t {
                 _ if t >= 'a' as u8 && t <= 'z' as u8 => 122 - t + 97,
                 _ if t >= 'A' as u8 && t <= 'Z' as u8 => 90 - t + 65,
                 _ => t,
            }})
        .collect(),
    )
    .unwrap(); 
    if ciphered == result{
        return Some(Ok(true));
    }
    return  Some(Err(CipherError::new(false, result)))
}