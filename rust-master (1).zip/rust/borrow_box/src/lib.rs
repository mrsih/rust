#[derive(Debug, Clone, Eq, PartialEq)]
pub struct GameSession {
    pub id: u32,
    pub p1: (String, u16),
    pub p2: (String, u16),
    pub nbr_of_games: u16
}

impl GameSession {
    pub fn new(i: u32, pl1: String, pl2: String, n: u16) -> Box<GameSession> {
         Box::new({
            GameSession {
                id: i,
                p1: (pl1, 0),
                p2: (pl2, 0),
                nbr_of_games: n
            }
        })
    }
    pub fn read_winner(&self) -> (String, u16) {
        println!("reading winner: {:?}", self);
        if self.p1.1 > self.p2.1 {
            return (self.p1.0.to_string(),self.p1.1)
        } else if self.p1.1< self.p2.1 {
            return (self.p2.0.to_string(),self.p2.1)
        } else {
            return ("Same score! tied".to_string(), self.p2.1)
        }
    }
    pub fn update_score(&mut self, user_name: String) {
        println!("updating score for {}", user_name);
        if self.nbr_of_games > 0 {
            self.nbr_of_games -= 1;
            if user_name == self.p1.0 {
                self.p1.1 += 1
            } else if user_name == self.p2.0 {
                self.p2.1 += 1
            }
        }
    }
    pub fn delete(self) -> String {
        let answer = "game deleted: id -> ".to_string() + &self.id.to_string();
        drop(self);
        return answer
    }
}