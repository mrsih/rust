#! /bin/bash

echo
echo "banana standard --output test00.txt"
go run . "banana standard --output test00.txt"
cat -e test00.txt

echo
echo "First\nTest shadow --output=test00.txt"
go run . "First\nTest" shadow --output=test00.txt
cat -e test00.txt


echo
echo "hello standard --output=test01.txt"
go run . "hello" standard --output=test01.txt
cat -e test01.txt

echo
echo "123 -> #$% standard --output=test02.txt"
go run . "123 -> #$%" standard --output=test02.txt
cat -e test02.txt

echo
echo "432 -> #$%&@ shadow --output=test03.txt"
go run . "432 -> #$%&@" shadow --output=test03.txt
cat -e test03.txt

echo
echo "There shadow --output=test04.txt"
go run . "There" shadow --output=test04.txt
cat -e test04.txt

echo
echo "123 -> \"#$%@ thinkertoy --output=test05.txt"
go run . "123 -> \"#$%@" thinkertoy --output=test05.txt
cat -e test05.txt

echo
echo "2 you thinkertoy --output=test06.txt"
go run . "2 you" thinkertoy --output=test06.txt
cat -e test06.txt

echo
echo "Testing long output! standard --output=test07.txt"
go run . "Testing long output!" standard --output=test07.txt
cat -e test07.txt
